package com.example.addition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    public void onStart() {
        super.onStart();
        Toast.makeText(getApplicationContext(),"Activity Started",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button add=findViewById(R.id.button);



       add.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               EditText Num1=(EditText) findViewById(R.id.textView6);
               EditText Num2=(EditText) findViewById(R.id.textView2);
               TextView Result=(TextView)  findViewById(R.id.textView3);
               int a=Integer.parseInt(Num1.getText().toString());
               int b=Integer.parseInt(Num2.getText().toString());
               int sum=a+b;

               Result.setText(Integer.toString(sum));

           }
       });

    }


    }
