package com.example.addition;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Addition2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addition2);
        Intent it1=getIntent();
        String sum=it1.getStringExtra("sum");
        TextView sum1=findViewById(R.id.textView4);
        sum1.setText(sum);
    }
}